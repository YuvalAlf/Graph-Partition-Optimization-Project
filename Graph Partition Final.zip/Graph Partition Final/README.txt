Branch & Bound:
	EXE:
		Code + EXE -- Branch & Bound >>> exe >>> Running.exe
	Code:
		Code + EXE -- Branch & Bound >>> GraphPartition_Branch&Bound_Code.zip
	Samples:
		Sample Runnings -- Branch & Bound

Local Search:
	EXE:
		Code + EXE -- Genetic + Local Search >>> exe >>> Running.exe
	Code:
		Code + EXE -- Genetic + Local Search >>> GraphPartition_Genetic_LocalSearch_Code.zip
	Samples:
		Sample Runnings -- Local Search

Genetic Algorithm:
	EXE:
		Code + EXE -- Genetic + Local Search >>> exe >>> Running.exe
	Code:
		Code + EXE -- Genetic + Local Search >>> GraphPartition_Genetic_LocalSearch_Code.zip
	Samples:
		Sample Runnings -- Genetic Algorithm